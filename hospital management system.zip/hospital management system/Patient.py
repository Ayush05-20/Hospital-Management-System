from person import Person
class Patient(Person):
    """Patient class"""

    def __init__(self, first_name, surname, age, mobile, postcode, illness_type):
        """
        Args:
            first_name (string): First name
            surname (string): Surname
            age (int): Age
            mobile (string): the mobile number
            address (string): address
        """
       
        super().__init__(first_name, surname)
        self.__age = age
        self.__mobile = mobile
        self.__postcode = postcode
        self.__doctor = 'Not assigned'
        self.__illness_type = illness_type
    def full_name(self) :
        return f"{self.get_first_name()} {self.get_surname()}"

    def get_doctor(self) :
        return self.__doctor
    def link(self, doctor):
        """Args: doctor(string): the doctor full name"""
        self.__doctor = doctor
        
    def get_age(self):
        return self.__age
    
    def get_postcode(self):
        return self.__postcode
    
    def print_symptoms(self):
        symptoms = input("Enter the symptom: ")
        return symptoms
    
    def get_illness(self):
        return self.__illness_type
    
    def set_illness(self, illness_type):
        self.__illness_type = illness_type
        
    def __str__(self):
        return f'{self.full_name():^30}|{str(self.__doctor):^30}|{self.__age:^5}|{self.__mobile:^15}|{self.__postcode:^10}'



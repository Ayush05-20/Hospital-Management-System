from Doctor import Doctor
class Admin:
    """A class that deals with the Admin operations"""
    def __init__(self, username, password, address = ''):
        """
        Args:
            username (string): Username
            password (string): Password
            address (string, optional): Address Defaults to ''
        """

        self.__username = username
        self.__password = password
        self.__address =  address
        self.load_details()
    
    def view(self,a_list):
        """
        print a list
        Args:
            a_list (list): a list of printables
        """
        for index, item in enumerate(a_list):
            print(f'{index+1:3}|{item}')

    def login(self) :
        """
        A method that deals with the login
        Raises:
            Exception: returned when the username and the password ...
                    ... don`t match the data registered
        Returns:
            string: the username
        """
    
        print("-----Login-----")
        #Get the details of the admin
        self.load_details()
        input_username = input("Username: ")
        input_password = input("Password: ")
        return input_username == self.__username and input_password == self.__password

    def find_index(self, index, doctors):
        
            # check that the doctor id exists          
        if index in range(0,len(doctors)):
            
            return True

        # if the id is not in the list of doctors
        else:
            return False
            
    def get_doctor_details(self) :
        """
        Get the details needed to add a doctor
        Returns:
            first name, surname and ...
                            ... the speciality of the doctor in that order.
        """
        first_name = input("Enter the first name of the doctor: ").capitalize()
        surname = input("Enter the surname of the doctor: ").capitalize()
        speciality = input("Enter the specility of the doctor: ").capitalize()
        return first_name , surname, speciality
       
    def doctor_management(self, doctors):
        """
        A method that deals with registering, viewing, updating, deleting doctors
        Args:
            doctors (list<Doctor>): the list of all the doctors names
        """

        print("-----Doctor Management-----")

        # menu
        print('Choose the operation:')
        print(' 1 - Register')
        print(' 2 - View')
        print(' 3 - Update')
        print(' 4 - Delete')
        print(' 5 - Quit')
        while True:
            try:
                op = input("Enter the option: ")
                # register
                if op == '1':
                    print("-----Register-----")

                    # get the doctor details
                    print('Enter the doctor\'s details:')
                    first_name, surname, speciality = self.get_doctor_details()

                    # check if the name is already registered
                    name_exists = False
                    for doctor in doctors:
                        if first_name == doctor.get_first_name() and surname == doctor.get_surname():
                            print('Name already exists.')
                            name_exists = True 
                            break 
                    if not name_exists:
                        doctors.append(Doctor(first_name, surname, speciality))
                        print('Doctor registered.')

                # View
                elif op == '2':
                    print("-----List of Doctors-----")
                    return (self.view(doctors))
                
                # Update
                elif op == '3':
                    while True:
                        print("-----Update Doctor`s Details-----")
                        print('ID |          Full name           |  Speciality')
                        self.view(doctors)
                        try:
                            index = int(input('Enter the ID of the doctor: ')) - 1
                            doctor_index = self.find_index(index, doctors)
                            if doctor_index != False:
                                break
                                
                            else:
                                print("Doctor not found")
                                # doctor_index is the ID mines one (-1)
                
                        except ValueError: # the entered id could not be changed into an int
                            print('The ID entered is incorrect')

                    # menu
                    print('Choose the field to be updated:')
                    print(' 1 First name')
                    print(' 2 Surname')
                    print(' 3 Speciality')
                    print(' 4 Quit')
                    while True:
                        try:
                            op = int(input('Input: ')) # make the user input lowercase
                            
                            if op == 1:
                                new_first_name = input("Enter the new first name: ")
                                doctors[index].set_first_name(new_first_name)
                            
                            elif op == 2:
                                new_surname = input("Enter the new surname: ")
                                doctors[index].set_surname(new_surname)
                            
                            elif op == 3:
                                new_speciality = input("Enter the new speciality name: ")
                                doctors[index].set_speciality(new_speciality)
                            
                            elif op == 4:
                                break
                            else:
                                return "Input error"
                            
                        except ValueError:
                            print("Value error")

                # Delete
                elif op == '4':
                    print("-----Delete Doctor-----")
                    print('ID |          Full Name           |  Speciality')
                    self.view(doctors)

                    doctor_index = int(input('Enter the ID of the doctor to be deleted: '))-1
                    if self.find_index(doctor_index, doctors) != False:
                        del doctors[doctor_index]
                        print(f" Doctor has been deleted sucessfully")
                    else:
                        print('The id entered is incorrect')

                elif op == "5":
                    break
                # if the id is not in the list of patients
                else:
                    print('Invalid operation choosen. Check your spelling!')
                    
            except ValueError:
                print("Invlid error")
        
                
    def family (self, patients):
        family_name = input("Enter surname: ")
        found = []
        
        for patient in patients:
            if patient.get_surname().lower() == family_name.lower():
                found.append(patient)
                
        if found:
            print(f"Family member with surname {family_name.capitalize()}")
            self.view(found)
        else:
            print(f"Patients with this surname {family_name} has not registred")

    def view_patient(self, patients):
        """
        print a list of patients
        Args:
            patients (list<Patients>): list of all the active patients
        """
        print("-----View Patients-----")
        print('ID |          Full Name           |      Doctor`s Full Name      | Age |    Mobile     | Postcode ')
        
        self.view(patients)
        
    def schedule_appointments(self, patients, doctors):
        
        print("Schedule appointments")
        
        print("View patients")
        self.view(patients)
        try:
            patient_index = int(input('Please enter the patient ID: ')) - 1
            
        except ValueError:
            print("Index error")
            
        print("Doctors")
        self.view(doctors)
        try:
            doctor_index = int(input('Please enter the doctor ID: ')) - 1

            date = input("Please enter date YY/MM/DD: ")
            time = input("Please enter time: ")
            
        except ValueError:
            print("Index error")
        
        doctors[doctor_index].set_appointments(patients[patient_index], date, time)

    def assign_doctor_to_patient(self, patients, doctors):
        """
        Allow the admin to assign a doctor to a patient
        Args:
            patients (list<Patients>): the list of all the active patients
            doctors (list<Doctor>): the list of all the doctors
        """
        print("-----Assign-----")

        print("-----Patients-----")
        print('ID |          Full Name           |      Doctor`s Full Name      | Age |    Mobile     | Postcode ')
        self.view(patients)

        patient_index = input('Please enter the patient ID: ')

        try:
            # patient_index is the patient ID mines one (-1)
            patient_index = int(patient_index) -1

            # check if the id is not in the list of patients
            if patient_index not in range(len(patients)):
                print('The id entered was not found.')
                return # stop the procedures

        except ValueError: # the entered id could not be changed into an int
            print('The id entered is incorrect')
            return # stop the procedures

        print("-----Doctors Select-----")
        print('Select the doctor that fits these symptoms:')
        patients[patient_index].print_symptoms() # print the patient symptoms

        print('--------------------------------------------------')
        print('ID |          Full Name           |  Speciality   ')
        self.view(doctors)
        doctor_index = input('Please enter the doctor ID: ')

        try:
            # doctor_index is the patient ID mines one (-1)
            doctor_index = int(doctor_index) -1

            # check if the id is in the list of doctors
            if self.find_index(doctor_index, doctors)!=False:
                
                doctors[doctor_index].add_patient(patients[patient_index].link(doctors[doctor_index].full_name()))
                # link the patients to the doctor and vice versa
                
                print(f'The {patients[patient_index].full_name()} is assign to the {doctors[doctor_index].full_name()}.')

            # if the id is not in the list of doctors
            else:
                print('The id entered was not found.')

        except ValueError: # the entered id could not be changed into an in
            print('The id entered is incorrect')

    def relocating(self, patients, doctors):
        print("---- Relocating Patients----")
        print('ID |          Full Name           |      Doctor`s Full Name      | Age |    Mobile     | Postcode ')
        self.view(patients)
        try:
            patient_index = int(input("Eneter the ID of patient: ")) - 1
            if patient_index not in range(len(patients)):
                print('The id entered was not found.')
                return
        except ValueError: # the entered id could not be changed into an int
            print('The id entered is incorrect')
            return
        patients[patient_index]
        
        print("-----Doctors Select-----")
        print('--------------------------------------------------')
        print('ID |          Full Name           |  Speciality   ')
        self.view(doctors)
        try: 
            doctor_index = int(input('Please enter the doctor ID: ')) - 1
           
            if self.find_index(doctor_index, doctors)!=False:
                new_doctor = doctors[doctor_index]
                new_doctor.add_patient(patients[patient_index].link(doctors[doctor_index].full_name()))
                print(f'The {patients[patient_index].full_name()} is now assign to the {new_doctor.full_name()}.')
            else:
                print('The id entered was not found.')
        except ValueError:
            print('The id entered is incorrect')
        
    def discharge(self, patients, discharged_patients):
        """
        Allow the admin to discharge a patient when treatment is done
        Args:
            patients (list<Patients>): the list of all the active patients
            discharge_patients (list<Patients>): the list of all the non-active patients
        """
        
        print("-----Discharge Patient-----")
        self.view(patients)
        try: 
            patient_index = int(input('Please enter the patient ID: '))-1
        
            if 0 <= patient_index < len(patients):
                discharged_patient = patients.pop(patient_index)  
                discharged_patients.append(discharged_patient)
                print(f"{discharged_patient.full_name()} has been discharged")
            
            else:
                print("invalid syntax")
        
        except ValueError:
            print("Id is incorrect")
            

    def view_discharge(self, discharged_patients):
        """
        Prints the list of all discharged patients
        Args:
            discharge_patients (list<Patients>): the list of all the non-active patients
        """

        print("-----Discharged Patients-----")
        print('ID |          Full Name           |      Doctor`s Full Name      | Age |    Mobile     | Postcode ')
        
        self.view(discharged_patients)
        
    def load_details(self):
        try:
            with open("/Users/ayush/hospital management system/admin_details.txt", "r") as file:
                self.__username = file.readline().strip()
                self.__password = file.readline().strip()
                self.__address = file.readline().strip()
        except FileNotFoundError:
            print("Admin details file not found. Using default values.")
    
    def save_details(self):
        with open("/Users/ayush/hospital management system/admin_details.txt", "w") as file:
            file.write(f"{self.__username}\n{self.__password}\n{self.__address}")
    def update_details(self):
        """
        Allows the user to update and change username, password and address
        """
        print('Choose the field to be updated:')
        print(' 1 Username')
        print(' 2 Password')
        print(' 3 Address')
        
        try:
            op = int(input('Input: '))

            if op == 1:
                new_username = input("Enter the new username: ")
                self.__username = new_username
                print("Username updated successfully.")
            elif op == 2:
                new_password = input('Enter the new password: ')
                confirm_password = input('Enter the new password again: ')
                if new_password == confirm_password:
                    self.__password = new_password
                    print("Password updated successfully.")
                else:
                    print("Passwords do not match. Password not updated.")
            elif op == 3:
                new_address = input("Enter new address: ")
                self.__address = new_address
                print("Address updated successfully.")
            else:
                print("Invalid input.")
            self.save_details()
        except ValueError:
    
            print("Id is not matched")
            
    def save_load_patients(self, patients):
        with open("Patients.txt", "a") as file:
            for patient in patients:
                patient_data = f"{patient.get_first_name()}, {patient.get_surname()} {patient.get_age()}, {patient.get_postcode()} \n"
                file.write(patient_data)
                
    def load_save_patients(self): 
        with open("Patients.txt", "r") as file:
            patient_lists = []
            for patient_data in file:
                patient_lists.append(patient_data.strip())  
                    
            if patient_lists:
                print("Patient Records")
                for record in patient_lists:
                    print(record)
                print("Loaded successfully")  
            else:
                print("File is empty")
    
    def management_report(self, patients, doctors):
        while True:
            print("----Management Report -----")
            print("1. For total doctor")
            print("2. Total patients per doctor")
            print("3. Doctor appointments per month")
            print("4. Total patients based on illness type")
            print("5. Quit")
            try:
                op = int(input("Enter the option: "))
            
                if op == 1:
                    
                    print(f"Total Doctor : {len(doctors)}")
                        
                elif op == 2:
                    print("Total Patients per Doctor:")
                    for doctor in doctors:
                        print(f"Dr.{doctor.full_name()} has {len(doctor.get_patients())} patients")
                            
                elif op == 3:
                    print("Doctor appointment per month")
                    month = input("Please enter year MM: ")
                    for  doctor in (doctors):
                        i = 0
                        for appt in doctor.get_appointments():
                            if appt["date"][5:7] == month:
                                i += 1
                        print(f"{doctor.full_name()} has {i} appointments this month {month}")
                    
                elif op == 4:
                    illness_count = {}
                    for patient in patients:
                        illness_type = patient.get_illness()
                        if illness_type:
                            if illness_type in illness_count:
                                illness_count[illness_type] += 1
                            else:
                                illness_count[illness_type] = 1
                                
                    print("Total patients based on illness type:")
                    for illness, count in illness_count.items():
                        print(f"{illness}: {count} patient(s)")
                elif op == 5:
                    break              
                else:
                    print("Index error")
            except ValueError:
                print("Input value error")
                
        
        
        
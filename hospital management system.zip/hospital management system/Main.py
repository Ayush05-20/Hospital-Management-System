# Imports
from Admin import Admin
from Doctor import Doctor
from Patient import Patient

def main():
    """
    the main function to be ran when the program runs
    """

    # Initialising the actors
    admin = Admin('admin','123','B1 1AB') # username is 'admin', password is '123'
    doctors = [Doctor('John','Smith','Internal Med.'), Doctor('Jone','Smith','Pediatrics'), Doctor('Jone','Carlos','Cardiology')]
    patients = [Patient('Sara','Smith', 20, '07012345678','B1 234',"chronic"), Patient('Mike','Jones', 37,'07555551234','L2 2AB',"infectious"), Patient('Daivd','Smith', 15, '07123456789','C1 ABC',"non-infectious")]
    discharged_patients = []

    # keep trying to login tell the login details are correct
    while True:
        if admin.login():
            running = True # allow the program to run
            break
        else:
            print('Incorrect username or password.')

    while running:
        # print the menu
        print('Choose the operation:')
        print(' 1- Register/view/update/delete doctor')
        print(' 2- Family grouping')
        print(' 3- Schedule appointments ')
        print(' 4- Discharge patients')
        print(' 5- View discharged patient')
        print(' 6- Assign doctor to a patient')
        print(' 7- Relocting Patients')
        print(' 8- Update admin detais')
        print(' 9- Management Report')
        print(' 10- Save Load Patient')
        print(' 11- Load Patient')
        print(' 12- Quit')

        # get the option
        op = input('Option: ')

        if op == '1':
            admin.doctor_management(doctors)
            
        elif op == "2":
            admin.family(patients)
            
        elif op == "3":
            admin.schedule_appointments(patients, doctors)
        elif op == '4':
            admin.view(patients)
            while True:
                op = input('Do you want to discharge a patient(Y/N):').lower()

                if op == 'yes' or op == 'y':
                    admin.discharge(patients, discharged_patients)
                elif op == 'no' or op == 'n':
                    
                    break

                # unexpected entry
                else:
                    print('Please answer by yes or no.')
        
        elif op == '5':
            admin.view_discharge(discharged_patients)

        elif op == '6':
            # 4- Assign doctor to a patient
            admin.assign_doctor_to_patient(patients, doctors)
        elif op == "7":
            admin.relocating(patients, doctors)
        elif op == '8':
            #Update admin detais
            admin.update_details()
        elif op == "9":
            
            admin.management_report(patients, doctors)
        elif op == "10":
            admin.save_load_patients(patients)
            
        elif op == "11":
            admin.load_save_patients()
            
        elif op == '12':
            print("The program is closed")
            break
        else:
            # the user did not enter an option that exists in the menu
            print('Invalid option. Try again')

if __name__ == '__main__':
    main()

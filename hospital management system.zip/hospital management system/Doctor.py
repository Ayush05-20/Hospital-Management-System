from person import Person
class Doctor(Person):
    """A class that deals with the Doctor operations"""

    def __init__(self, first_name, surname, speciality):
        """
        Args:
            first_name (string): First name
            surname (string): Surname
            speciality (string): Doctor`s speciality
        """
        super().__init__(first_name, surname)
       
        self.__speciality = speciality
        self.__patients = []
        self.__appointments = []

    def full_name(self) :
        return f"{self.get_first_name()} {self.get_surname()}"

    def get_speciality(self) :
       
       return self.__speciality
   
    def set_speciality(self, new_speciality):
        
        self.__speciality = new_speciality
        
    def get_patients(self):
        return self.__patients
    
    def add_patient(self, patient):
        self.__patients.append(patient)

    def get_appointments(self):
        return self.__appointments
    
    def set_appointments(self, patients, date, time):
        appointments = {
                        "patients": patients.full_name(), 
                        "date" : date, 
                        "time" : time}
        self.__appointments.append(appointments)
        print(f"Appointments secudule of {patients.full_name()} with Dr.{self.full_name()} is on {date} at {time}")

    def __str__(self) :
        return f'{self.full_name():^30}|{self.__speciality:^15}'


